// const URL = 'http://localhost/chat_bewell_web/php/Chat_bewell'
// const URL_FILE = 'http://localhost/chat_bewell_web/php/fichiers'


const URL = '/chat_bewell_web/php/Chat_bewell'
const URL_FILE = '/chat_bewell_web/php/fichiers'