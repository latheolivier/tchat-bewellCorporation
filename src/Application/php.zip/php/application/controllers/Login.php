<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function index()
    {



        $data = array(
            '2011-07-29' => 39,
            '2011-07-30' => 39,
            '2011-07-31' => 39,
            '2011-08-01' => 40,
        );

        $keys = array_keys($data);

        foreach ($keys as &$key) {
            list(, $month) = sscanf($key, '%d-%d-%d');
            $month = sprintf("%02d", $month - 1);
            $key[5] = $month[0];
            $key[6] = $month[1];
        }
        unset($key);

        $data = array_combine($keys, $data);

        print_r($data);
    }
}