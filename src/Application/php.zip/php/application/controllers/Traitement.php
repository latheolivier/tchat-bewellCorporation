<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Traitement extends CI_Controller
{


    public function cors()
    {
        header("Access-Control-Allow-Origin: *");

        header("Access-Control-Allow-Headers: Authorization, Content-Type");

        header('content-type: application/json; charset=utf-8');
    }



    public function Check_user()
    {
        $this->cors();

        $donnee = array(
            'user_name' => $_POST['user_name'],
            'listing_id' => $_POST['listing_id'],
        );

        $count = $this->Traitement_model->Check_user($donnee);

        if ($count == 0) {
            $resultat = array(
                'resultat' => 'not_found'
            );
            echo json_encode($resultat);
        }
        if ($count > 0) {
            $this->Recuperer_all_discussion($_POST['user_name'], $_POST['listing_id']);
        }
    }








    public function Recuperer_all_discussion($user_name, $listing_id)
    {
        $this->cors();
        $where_1 = array(
            'listing_id' => $listing_id,
            'user_name' => $user_name,
        );


        $data = $this->Traitement_model->Recuperer_all_discussion($where_1);

        $resultat = array(
            'resultat' => $data
        );

        echo json_encode($resultat);
    }




    //  function ajout de message et de creation de compte si possible


    public function Add_message()
    {

        $this->cors();

        $donnee = array(
            'user_name' => $_POST['user_name'],
            'listing_id' => $_POST['listing_id'],
        );

        $count = $this->Traitement_model->Check_user($donnee);


        if ($count == 0) {

            // add uer
            $nombre_total = $this->Traitement_model->Count_user();

            $donnee_user = array(
                'user_name' => $_POST['user_name'],
                'listing_id' => $_POST['listing_id'],
                'img_listing' => $_POST['img_listing'],
                'listing_title' => $_POST['listing_title'],
                'position' => $nombre_total + 1,
            );
            $this->Traitement_model->Add_user($donnee_user);


            // add admin

            // $nombre_total_2 = $this->Traitement_model->Count_user();

            // $donnee_user = array(
            //     'user_name' => "admin_apefa",
            //     'listing_id' => $_POST['listing_id'],
            //     'img_listing' => $_POST['img_listing'],
            //     'position' => $nombre_total_2 + 1,
            // );
            // $this->Traitement_model->Add_user($donnee_user);



            //  add message



            $donnee_message = array(
                'user_name' => $_POST['user_name'],
                'listing_id' => $_POST['listing_id'],
                'message' => $_POST['message'],
                'emetteur' => $_POST['user_name'],
                'view_emetteur' => true,
                'view_recepteur' => false,
                'dates' =>  date('H:i')

            );



            $this->Traitement_model->Add_message($donnee_message);



            //  add last message



            $where_last_1 = array(
                'user_name' => $_POST['user_name'],
                'listing_id' => $_POST['listing_id'],
            );

            $last_msg_user = array(
                'last_message' => $_POST['message'],
                'position' => date('Y-m-d H:i:s'),
                'dates_last_msg' => date('Y-m-d H:i:s'),
            );



            $this->Traitement_model->Add_last_msg($where_last_1, $last_msg_user);


            //  recuperation de dernnier mesage


            //############################################

            $this->Recuperer_last_discussion($_POST['user_name'], $_POST['listing_id']);

            $this->Calcul_non_lu_admin($_POST['user_name'], $_POST['listing_id']);

            $this->Modifier_positon($_POST['user_name'], $_POST['listing_id']);

            $this->Modifier_positon_genera($_POST['user_name'], $_POST['listing_id']);
        }



        if ($count > 0) {


            $donnee_message = array(
                'user_name' => $_POST['user_name'],
                'listing_id' => $_POST['listing_id'],
                'message' => $_POST['message'],
                'emetteur' => $_POST['user_name'],
                'view_emetteur' => true,
                'view_recepteur' => false,
                'dates' => date('H:i'),
            );

            $this->Traitement_model->Add_message($donnee_message);



            //  add last message

            $where_last_1 = array(
                'user_name' => $_POST['user_name'],
                'listing_id' => $_POST['listing_id'],
            );

            $last_msg_user = array(
                'last_message' => $_POST['message'],
                'position' => date('Y-m-d H:i:s'),
                'dates_last_msg' => date('Y-m-d H:i:s'),
            );



            $this->Traitement_model->Add_last_msg($where_last_1, $last_msg_user);


            //############################################


            $this->Calcul_non_lu_admin($_POST['user_name'], $_POST['listing_id']);

            $this->Recuperer_last_discussion($_POST['user_name'], $_POST['listing_id']);

            $this->Modifier_positon($_POST['user_name'], $_POST['listing_id']);

            $this->Modifier_positon_genera($_POST['user_name'], $_POST['listing_id']);
        }

        // echo json_encode($resultat);
    }
















    public function Modifier_positon($user_name, $listing_id)
    {
        $this->cors();
        // recuperer et afficher les message dans le pop up
        $donee = array(
            'user_name' => $user_name,
        );


        $data = $this->Traitement_model->Mes_discussons($donee);

        $index = 0;
        // $total = count($data);

        foreach ($data as $key) {

            $index++;

            if ($key->listing_id == $listing_id) {

                $where_id_1 = array(
                    'id' => $key->id,
                );

                $data_position_1 = array(
                    'position' => 0,
                );

                $this->Traitement_model->Modifier_positon($where_id_1, $data_position_1);
            } else {

                $where_id_2 = array(
                    'id' => $key->id,
                );

                $data_position = array(
                    'position' => $index
                );

                $this->Traitement_model->Modifier_positon($where_id_2, $data_position);
            }
        }
    }




    public function Recuperer_last_discussion($user_name, $listing_id)
    {
        $this->cors();
        // recuperer et afficher les message dans le pop up
        $resultat = array(
            'resultat' => 'liste discussion'
        );

        echo json_encode($resultat);
    }







    public function Message_per_user()
    {

        $this->cors();

        $where_1 = array(
            'user_name' => $_POST['user_name'],
            'listing_id' => $_POST['listing_id'],
        );


        $data = $this->Traitement_model->Recuperer_all_discussion($where_1);

        $resultat = array(
            'resultat' => $data
        );

        echo json_encode($resultat);



        // $this->Calcul_non_lu_admin($_POST['user_name'], $_POST['listing_id']);

        $this->Clear_non_lu_user($_POST['user_name'], $_POST['listing_id']);
    }








    public function Clear_non_lu_user($user_name, $listing_id)
    {

        $this->cors();
        $where_1 = array(
            'user_name' => $user_name,
            'listing_id' => $listing_id,
            'emetteur' => 'admin_apefa',
        );

        $datas = array(
            'view_emetteur' => true,
        );

        $this->Traitement_model->Clear_non_lu_user($where_1, $datas);


        $where_3 = array(
            'user_name' => $user_name,
            'listing_id' => $listing_id,
        );

        $datassss = array(
            'non_lu_user' => 0,
        );

        $this->Traitement_model->not_lu_admin($where_3, $datassss);
    }





    public function Calcul_non_lu_admin($user_name, $listing_id)
    {

        $this->cors();

        $where_1 = array(
            'user_name' => $user_name,
            'listing_id' => $listing_id
        );


        $data = $this->Traitement_model->Recuperer_all_discussion($where_1);
        $nbr = 0;
        foreach ($data as $key) {
            if ($key->view_recepteur == false) {
                $nbr++;
                # code...
            }
        }


        $datas = array(
            'non_lu_admin' => $nbr,
        );

        $this->Traitement_model->not_lu_admin($where_1, $datas);
    }








    public function Mes_discussons()
    {

        $this->cors();

        $donee = array(
            'user_name' => $_POST['user_name'],
        );


        $data = $this->Traitement_model->Mes_discussons($donee);
        // $ùessage = $this->Traitement_model->Mes_messages($donee);

        $resultat = array(
            'resultat' => $data,
        );

        echo json_encode($resultat);
    }



















































    public function Message_per_user_admin()
    {

        $this->cors();

        $where_1 = array(
            'user_name' => $_POST['user_name'],
            'listing_id' => $_POST['listing_id'],
        );


        $data = $this->Traitement_model->Recuperer_all_discussion($where_1);

        $resultat = array(
            'resultat' => $data
        );

        echo json_encode($resultat);



        $this->Calcul_non_lu_user($_POST['user_name'], $_POST['listing_id']);
        $this->Clear_non_lu_admin($_POST['user_name'], $_POST['listing_id']);
    }










    public function Admin_add_message()
    {

        $this->cors();



        $donnee_message = array(
            'user_name' => $_POST['user_name'],
            'listing_id' => $_POST['listing_id'],
            'message' => $_POST['message'],
            'emetteur' => "admin_apefa",
            'view_emetteur' => false,
            'view_recepteur' => true,
            'dates' => date('H:i'),
        );

        $this->Traitement_model->Add_message($donnee_message);



        //  add last message

        $where_last_1 = array(
            'user_name' => $_POST['user_name'],
            'listing_id' => $_POST['listing_id'],
        );

        $last_msg_user = array(
            'last_message' => $_POST['message'],
            'position' => date('Y-m-d H:i:s'),
            'dates_last_msg' => date('Y-m-d H:i:s'),
        );



        $this->Traitement_model->Add_last_msg($where_last_1, $last_msg_user);



        $resultat = array(
            'resultat' => 'save'
        );

        echo json_encode($resultat);



        $this->Modifier_positon_genera($_POST['user_name'], $_POST['listing_id']);
        $this->Modifier_positon($_POST['user_name'], $_POST['listing_id']);

        $this->Calcul_non_lu_user($_POST['user_name'], $_POST['listing_id']);
        $this->Clear_non_lu_admin($_POST['user_name'], $_POST['listing_id']);
    }




    public function Modifier_positon_genera($user_name, $listing_id)
    {
        // recuperer et afficher les message dans le pop up

        $this->cors();

        $data = $this->Traitement_model->Recuperer_all_pour_admin();

        $index = 0;
        // $total = count($data);

        foreach ($data as $key) {

            $index++;

            if ($key->listing_id == $listing_id && $key->user_name == $user_name) {

                $where_id_1 = array(
                    'id' => $key->id,
                );

                $data_position_1 = array(
                    'all_position' => 0,
                );

                $this->Traitement_model->Modifier_positon($where_id_1, $data_position_1);
            } else {

                $where_id_2 = array(
                    'id' => $key->id,
                );

                $data_position = array(
                    'all_position' => $index
                );

                $this->Traitement_model->Modifier_positon($where_id_2, $data_position);
            }
        }
    }





    public function Clear_non_lu_admin($user_name, $listing_id)
    {

        $this->cors();

        $where_1 = array(
            'user_name' => $user_name,
            'listing_id' => $listing_id,
            // 'emetteur' => 'admin_apefa',
        );

        $datas = array(
            'view_recepteur' => true,
        );

        $this->Traitement_model->Clear_non_lu_user($where_1, $datas);



        $where_3 = array(
            'user_name' => $user_name,
            'listing_id' => $listing_id,
        );

        $datassss = array(
            'non_lu_admin' => 0,
        );

        $this->Traitement_model->not_lu_admin($where_3, $datassss);
    }







    public function Calcul_non_lu_user($user_name, $listing_id)
    {

        $this->cors();

        $where_1 = array(
            'user_name' => $user_name,
            'listing_id' => $listing_id
        );


        $data = $this->Traitement_model->Recuperer_all_discussion($where_1);
        $nbr = 0;
        foreach ($data as $key) {
            if ($key->view_emetteur == false) {
                $nbr++;
                # code...
            }
        }


        $datas = array(
            'non_lu_user' => $nbr,
        );

        $this->Traitement_model->not_lu_admin($where_1, $datas);
    }











    public function All_message_admin()
    {

        $this->cors();
        
        $data = $this->Traitement_model->Recuperer_all_pour_admin();

        $resultat = array(
            'resultat' => $data
        );

        echo json_encode($resultat);
    }





    //##############################################
}