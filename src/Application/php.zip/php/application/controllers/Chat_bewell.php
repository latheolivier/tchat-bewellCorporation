<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Chat_bewell extends CI_Controller
{


    public function cors()
    {
        header("Access-Control-Allow-Origin: *");

        header("Access-Control-Allow-Headers: Authorization, Content-Type");

        header('content-type: application/json; charset=utf-8');
    }



    public function index()
    {
        echo 'salut';
    }






    public function creer_compte()
    {
        $this->cors();

        $donnee = array(
            'pseudo' => $_POST['pseudo'],
        );


        $count = $this->Traitement_model->Check_user($donnee);



        if ($count == 0) {

            if (isset($_FILES['image']['name'])) {

                $config['upload_path'] = './fichiers/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4';
                $config['encrypt_name']        = true;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('image')) {
                    echo 'error';
                } else {

                    $Nom_fichier = $this->upload->data('file_name');


                    $donnee = array(
                        'pseudo' => $_POST['pseudo'],
                        'mot_de_passe' => $_POST['mot_de_passe'],
                        'profile' =>  $Nom_fichier,
                        'role' => "user",
                        'type' => "user",
                    );

                    $this->Traitement_model->Add_user($donnee);

                    ///   send notification

                    $resultat = array(
                        'resultat' => 'save'
                    );

                    echo json_encode($resultat);
                }

                // ########################
            } else {
                $donnee = array(
                    'pseudo' => $_POST['pseudo'],
                    'mot_de_passe' => $_POST['mot_de_passe'],
                    'role' => "user",
                    'type' => "user",
                );

                $count = $this->Traitement_model->Add_user($donnee);

                $resultat = array(
                    'resultat' => 'save'
                );

                echo json_encode($resultat);
            }
        } else {
            $resultat = array(
                'resultat' => 'user_found'
            );

            echo json_encode($resultat);
        }
    }




    public function creer_compte_groupe()
    {
        $this->cors();

        $donnee = array(
            'pseudo' => $_POST['pseudo'],
        );


        $count = $this->Traitement_model->Check_user($donnee);



        if ($count == 0) {

            if (isset($_FILES['image']['name'])) {

                $config['upload_path'] = './fichiers/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4';
                $config['encrypt_name']        = true;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('image')) {
                    echo 'error';
                } else {

                    $Nom_fichier = $this->upload->data('file_name');


                    $donnee = array(
                        'pseudo' => $_POST['pseudo'],
                        'profile' =>  $Nom_fichier,
                        'role' => "user",
                        'type' => "groupe",
                    );

                    $this->Traitement_model->Add_user($donnee);

                    ///   enregistrer ans la table admin

                    $toal_amis = $this->Traitement_model->toal_amis();


                    $donnee_1 = array(
                        // 'emetteur' => $_POST['pseudo'],
                        // 'recepteur' =>  $_POST['admin'],

                        'recepteur' => $_POST['pseudo'],
                        'emetteur' =>  $_POST['admin'],
                        'id_discussion' => $toal_amis + 1,
                        'position' => $toal_amis + 1,
                        'type' => 'groupe',
                        'last_message' => $toal_amis . ' Amis',
                    );

                    $this->Traitement_model->ajouter_amis($donnee_1);





                    ///   send notification

                    $resultat = array(
                        'nom_groupe' => $_POST['pseudo'],
                        'id_discussion_group' => $toal_amis + 1,
                        'all_users' => $this->Traitement_model->all_user(),
                    );

                    echo json_encode($resultat);
                }

                // ########################
            } else {
                $donnee = array(
                    'pseudo' => $_POST['pseudo'],
                    'role' => "user",
                    'type' => "groupe",
                );

                $count = $this->Traitement_model->Add_user($donnee);


                ///   enregistrer ans la table admin

                $toal_amis = $this->Traitement_model->toal_amis();


                $donnee_2 = array(
                    // 'emetteur' => $_POST['pseudo'],
                    // 'recepteur' =>  $_POST['admin'],
                    'recepteur' => $_POST['pseudo'],
                    'emetteur' =>  $_POST['admin'],
                    'id_discussion' => $toal_amis + 1,
                    'position' => $toal_amis + 1,
                    'last_message' => $toal_amis . ' Amis',
                );

                $this->Traitement_model->ajouter_amis($donnee_2);

                ///   send notification

                $resultat = array(
                    'nom_groupe' => $_POST['pseudo'],
                    'id_discussion_group' => $toal_amis + 1,
                    'all_users' => $this->Traitement_model->all_user(),
                );

                echo json_encode($resultat);
            }
        } else {
            $resultat = array(
                'resultat' => 'user_found'
            );

            echo json_encode($resultat);
        }
    }



    public function connexion()
    {

        $this->cors();


        $donnee = array(
            'pseudo' => $_POST['pseudo'],
            'mot_de_passe' => $_POST['mot_de_passe'],
        );

        $count = $this->Traitement_model->Check_user($donnee);


        if ($count == 0) {

            $resultat = array(
                'resultat' => 'not_found'
            );

            echo json_encode($resultat);
        } else {

            $resultat = array(
                'resultat' => 'user_found'
            );

            echo json_encode($resultat);
        }
    }







    public function information_personnel()
    {

        $this->cors();

        $where_1 = array(
            'pseudo' => $_POST['pseudo'],
        );

        $data = $this->Traitement_model->information_personnel($where_1);

        $resultat = array(
            'resultat' => $data
        );

        echo json_encode($resultat);



        // $this->Calcul_non_lu_admin($_POST['user_name'], $_POST['listing_id']);

    }








    public function all_user()
    {

        $this->cors();

        $where_1 = array(
            'pseudo' => $_POST['pseudo'],
        );

        $resultat = array(
            'resultat' => $this->Traitement_model->information_personnel($where_1),
            'all_users' => $this->Traitement_model->all_user(),
        );

        echo json_encode($resultat);



        // $this->Calcul_non_lu_admin($_POST['user_name'], $_POST['listing_id']);

    }






    public function rechercher_user()
    {
        $this->cors();

        $data = $this->Traitement_model->all_user();

        $resultat = array(
            'resultat' => $data
        );

        echo json_encode($resultat);
    }





    public function send_invatation()
    {
        // accept_emetteur
        // accept_recepteur

        $this->cors();


        $donnee_0 = array(
            'emetteur' => $_POST['emetteur'],
            'recepteur' => $_POST['recepteur'],

        );


        $count_0 = $this->Traitement_model->verifier_invitation($donnee_0);


        if ($count_0 == 0) {

            $donnee_1 = array(
                'emetteur' => $_POST['recepteur'],
                'recepteur' => $_POST['emetteur'],
            );


            $count_1 = $this->Traitement_model->verifier_invitation($donnee_1);

            if ($count_1 > 0) {
                # code...
                $resultat = array(
                    'resultat' => 'deja_invite'
                );

                echo json_encode($resultat);
            }
            // ###############
            else {


                $data_invite_1 = array(
                    'emetteur' => $_POST['emetteur'],
                    'recepteur' => $_POST['recepteur'],
                    'accept_emetteur' => true,
                    'accept_recepteur' => false,
                    'type_invitation' => 'user',
                );


                $this->Traitement_model->add_invitation($data_invite_1);

                $resultat = array(
                    'resultat' => 'save'
                );

                echo json_encode($resultat);
            }
        }

        // ###################################
        else {


            $resultat = array(
                'resultat' => 'deja_invite'
            );

            echo json_encode($resultat);
        }
    }








    public function send_invatation_groupe()
    {
        // accept_emetteur
        // accept_recepteur


        // les_donnees.append('emetteur', NOM_DU_GROUPE[0])
        // les_donnees.append('id_discussion', ID_DISCUSSIONS_GROUPE[0])
        // les_donnees.append('id', params)




        $this->cors();


        $donnee_00 = array(
            'id' => $_POST['id'],
        );


        $resultat = $this->Traitement_model->information_personnel($donnee_00);



        foreach ($resultat as $key => $values) {


            $donnee_00 = array(
                'id_discussion' => $_POST['id_discussion'],
                'emetteur' => $values->pseudo,
                'recepteur' =>  $_POST['emetteur'],
            );

            $recuperer = $this->Traitement_model->mes_amis($donnee_00);

            if (count($recuperer) == 0) {
                # code...
                $toal_amis = $this->Traitement_model->toal_amis();
                $donnee_1 = array(
                    // 'emetteur' => $_POST['emetteur'],
                    // 'recepteur' => $values->pseudo,

                    'recepteur' => $_POST['emetteur'],
                    'emetteur' =>   $values->pseudo,

                    'id_discussion' => $_POST['id_discussion'],
                    'position' => $toal_amis + 1,
                    'last_message' => $toal_amis . ' Amis',
                    'type' => 'groupe',
                );

                $this->Traitement_model->ajouter_amis($donnee_1);

                $resultat = array(
                    'resultat' => 'save'
                );

                echo json_encode($resultat);
            } else {

                $resultat = array(
                    'resultat' => 'deja_invite'
                );

                echo json_encode($resultat);
            }
        }
    }








    public function mes_invitation()
    {
        // accept_emetteur
        // accept_recepteur

        $this->cors();


        $donnee_0 = array(
            'accept_recepteur' => false,
            'recepteur' => $_POST['recepteur'],
        );


        $count_0 = $this->Traitement_model->mes_invitation($donnee_0);


        $resultat = array(
            'resultat' => $count_0
        );

        echo json_encode($resultat);
    }







    public function valider_invitation()
    {
        # code...

        $this->cors();

        $where = array(
            'id' => $_POST['id']
        );

        $data_invite_1 = array(
            'accept_recepteur' => true,
        );


        $this->Traitement_model->valider_invitation($where, $data_invite_1);




        // row invitation valider
        $count_0 = $this->Traitement_model->mes_invitation($where);

        $this->ajouter_amis($_POST['id']);


        $resultat = array(
            'resultat' => 'save',
            'row_invitation' =>  $this->Traitement_model->mes_invitation($where)
        );

        echo json_encode($resultat);
    }







    public function ajouter_amis($id)
    {

        //  verifier si cest un groupe





        $where = array(
            'id' => $id
        );

        $count_0 = $this->Traitement_model->mes_invitation($where);







        $toal_amis = $this->Traitement_model->toal_amis();

        foreach ($count_0 as $key => $value) {
            # code...
            $donnee_1 = array(
                'emetteur' => $value->emetteur,
                'recepteur' => $value->recepteur,
                'id_discussion' => $toal_amis + 1,
                'position' => $toal_amis + 1,
                'last_message' => $id . ' Amis',
                'type' => 'user',
            );

            $this->Traitement_model->ajouter_amis($donnee_1);
        }
    }











    public function mes_amis()
    {
        // accept_emetteur
        // accept_recepteur

        $this->cors();


        $donnee_0 = array(
            'emetteur' => $_POST['emetteur'],
        );
        $donnee_1 = array(
            'recepteur' => $_POST['emetteur'],
        );

        $count_0 = $this->Traitement_model->mes_amis_2($donnee_0, $donnee_1);


        $resultat = array(
            'resultat' => $count_0,
            'all_user' => $this->Traitement_model->all_user(),
        );

        echo json_encode($resultat);
    }






    public function check_message()
    {

        $this->cors();


        // recuperer tous les messages
        $donnee_0 = array(
            'id_discussion' => $_POST['id_discussion'],
        );

        $les_messages = $this->Traitement_model->nos_messages($donnee_0);



        $donnee_1 = array(
            'id_discussion' => $_POST['id_discussion'],
        );

        $recepteur_info = $this->Traitement_model->mes_amis($donnee_1);



        $resultat = array(
            'resultat' => $les_messages,
            'recepteur_info' => $recepteur_info,
        );

        echo json_encode($resultat);
    }







    public function send_messages()
    {

        $this->cors();


        // recuperer tous les messages

        if (!empty($_FILES['fichier']['name']) && count(array_filter($_FILES['fichier']['name'])) > 0) {
            # code...
            $stock_image = array();
            $nom_des_image = array();

            for ($i = 0; $i < count($_FILES['fichier']['name']); $i++) {

                $_FILES['file']['name'] = $_FILES['fichier']['name'][$i];
                $_FILES['file']['type'] = $_FILES['fichier']['type'][$i];
                $_FILES['file']['tmp_name'] = $_FILES['fichier']['tmp_name'][$i];
                $_FILES['file']['size'] = $_FILES['fichier']['size'][$i];

                $nom_reel = $_FILES['file']['name'];

                $config['upload_path'] = './fichiers/';
                $config['allowed_types']        = 'jpg|png|jpeg|gif|pdf|doc|docx';
                $config['encrypt_name']        = true;

                $this->load->library('upload', $config);
                $this->upload->initialize($config);


                if ($this->upload->do_upload('file')) {

                    $Nom_fichier = $this->upload->data('file_name');
                    array_push($stock_image, $Nom_fichier);
                    array_push($nom_des_image, $nom_reel);
                }
            }

            $donnee_0 = array(
                'id_discussion' => $_POST['id_discussion'],
                'emetteur_msg' => $_POST['emetteur_msg'],
                'recepteur_msg' => $_POST['recepteur_msg'],
                'message' => $_POST['message'],
                'id_tag' => $_POST['id_tag'],
                'view_emetteur' => true,
                'view_recepteur' => false,
                'dates' => date('H:i'),
            );

            for ($j = 0; $j < count($stock_image); $j++) {
                $donnee_0['image_msg_' . $j] = $stock_image[$j];
            }
            for ($j = 0; $j < count($nom_des_image); $j++) {
                $donnee_0['titre_img_' . $j] = $nom_des_image[$j];
            }

            $this->Traitement_model->send_messages($donnee_0);
        } else {
            $donnee_00 = array(
                'id_discussion' => $_POST['id_discussion'],
                'emetteur_msg' => $_POST['emetteur_msg'],
                'recepteur_msg' => $_POST['recepteur_msg'],
                'message' => $_POST['message'],
                'id_tag' => $_POST['id_tag'],
                'view_emetteur' => true,
                'view_recepteur' => false,
                'dates' => date('H:i'),
            );



            $this->Traitement_model->send_messages($donnee_00);
        }












        $where_2 = array(
            'id_discussion' => $_POST['id_discussion'],
        );

        $datas = array(
            'last_message' =>  $_POST['message'],
        );

        $this->Traitement_model->not_lu_recepteur($where_2, $datas);


        $this->Calcul_non_lu_recepteur($_POST['id_discussion'], $_POST['emetteur_msg']);

        $this->Modifier_positon_genera($_POST['id_discussion'], $_POST['emetteur_msg']);


        $resultat = array(
            'resultat' => 'save',
        );

        echo json_encode($resultat);
    }










    public function send_messages_groupe()
    {

        $this->cors();


        $where_100 = array(
            'recepteur' => $_POST['nom_groupe'],
            'emetteur' => $_POST['emetteur'],
        );

        $verifie =   $les_users = $this->Traitement_model->mes_amis($where_100);

        if (count($verifie) > 0) {
            # code...


            // recuperer tous les messages


            if (!empty($_FILES['fichier']['name']) && count(array_filter($_FILES['fichier']['name'])) > 0) {
                # code...
                $stock_image = array();
                $nom_des_image = array();

                for ($i = 0; $i < count($_FILES['fichier']['name']); $i++) {

                    $_FILES['file']['name'] = $_FILES['fichier']['name'][$i];
                    $_FILES['file']['type'] = $_FILES['fichier']['type'][$i];
                    $_FILES['file']['tmp_name'] = $_FILES['fichier']['tmp_name'][$i];
                    $_FILES['file']['size'] = $_FILES['fichier']['size'][$i];

                    $nom_reel = $_FILES['file']['name'];

                    $config['upload_path'] = './fichiers/';
                    $config['allowed_types']        = 'jpg|png|jpeg|gif|pdf|doc|docx';
                    $config['encrypt_name']        = true;

                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);


                    if ($this->upload->do_upload('file')) {

                        $Nom_fichier = $this->upload->data('file_name');
                        array_push($stock_image, $Nom_fichier);
                        array_push($nom_des_image, $nom_reel);
                    }
                }

                $donnee_0 = array(
                    'nom_groupe' => $_POST['nom_groupe'],
                    'emetteur_msg' => $_POST['emetteur'],
                    'message' => $_POST['message'],
                    'dates' => date('H:i'),
                    'id_tag' => $_POST['id_tag'],
                );

                for ($j = 0; $j < count($stock_image); $j++) {
                    $donnee_0['image_msg_' . $j] = $stock_image[$j];
                }

                for ($j = 0; $j < count($nom_des_image); $j++) {
                    $donnee_0['titre_img_' . $j] = $nom_des_image[$j];
                }

                $this->Traitement_model->send_messages_groupe($donnee_0);
            } else {
                $donnee_00 = array(
                    'nom_groupe' => $_POST['nom_groupe'],
                    'emetteur_msg' => $_POST['emetteur'],
                    'message' => $_POST['message'],
                    'dates' => date('H:i'),
                    'id_tag' => $_POST['id_tag'],
                );
                $this->Traitement_model->send_messages_groupe($donnee_00);
            }




            // send message non lue

            $donnee_10 = array(
                'recepteur' => $_POST['nom_groupe'],
            );


            $les_user = $this->Traitement_model->mes_amis($donnee_10);

            foreach ($les_user as $key => $value) {
                if ($value->emetteur == $_POST['emetteur']) {
                    # code...
                    $donnee_11 = array(
                        'nom_groupe' => $_POST['nom_groupe'],
                        'emetteur_msg' => $_POST['emetteur'],
                        'id_discussion' => $_POST['id_discussion'],
                        'lu' => true,
                    );

                    $this->Traitement_model->add_lu_groupe($donnee_11);
                } else {
                    $donnee_12 = array(
                        'nom_groupe' => $_POST['nom_groupe'],
                        'emetteur_msg' => $value->emetteur,
                        'id_discussion' => $_POST['id_discussion'],
                        'lu' => false,
                    );

                    $this->Traitement_model->add_lu_groupe($donnee_12);
                }
            }






            // calcull non lue groupe



            $donnee_20 = array(
                'recepteur' => $_POST['nom_groupe'],
                'emetteur !=' => $_POST['emetteur'],
            );

            $les_users = $this->Traitement_model->mes_amis($donnee_20);




            foreach ($les_users as $key => $value) {

                // if ($value->emetteur != $emetteur) {

                $donnee_21 = array(
                    'nom_groupe' => $_POST['nom_groupe'],
                    'emetteur_msg' => $value->emetteur,
                    // 'id_discussion' => $id_discussion,
                    'lu' => false,
                );

                $calcul = $this->Traitement_model->select_lu_groupe($donnee_21);


                $where_32 = array(
                    'recepteur' => $_POST['nom_groupe'],
                    'emetteur' =>  $value->emetteur,
                );

                $datas = array(
                    'non_lu_emetteur' => $calcul,
                );

                $this->Traitement_model->not_lu_recepteur($where_32, $datas);
                // }
            }






            //  ajouter last message

            $where_2 = array(
                'recepteur' => $_POST['nom_groupe'],
                'id_discussion' => $_POST['id_discussion'],

            );

            $datas = array(
                'last_message' =>  $_POST['message'],
            );


            $this->Traitement_model->not_lu_recepteur($where_2, $datas);










            $this->Modifier_positon_genera($_POST['id_discussion'], $_POST['emetteur']);


            $resultat = array(
                'resultat' => 'save',
            );

            echo json_encode($resultat);
        } else {
            $resultat = array(
                'resultat' => 'user_delete_from_groupe',
            );

            echo json_encode($resultat);
        }
        // $this->Calcul_non_lu_recepteur_groupe($_POST['id_discussion'], $_POST['nom_groupe'], $_POST['emetteur']);
    }







    public function Calcul_non_lu_recepteur_groupe($id_discussion, $nom_groupe, $emetteur)
    {

        $this->cors();
        $donnee_10 = array(
            'recepteur' => $nom_groupe,
            'emetteur !=' => $emetteur,
        );

        $les_user = $this->Traitement_model->mes_amis($donnee_10);




        foreach ($les_user as $key => $value) {

            // if ($value->emetteur != $emetteur) {

            $donnee_11 = array(
                'nom_groupe' => $nom_groupe,
                'emetteur_msg' => $value->emetteur,
                // 'id_discussion' => $id_discussion,
                // 'lu' => false,
            );

            $calcul = $this->Traitement_model->select_lu_groupe($donnee_11);


            $where_2 = array(
                'recepteur' => $nom_groupe,
                'emetteur' =>  $value->emetteur,
            );

            $datas = array(
                'non_lu_emetteur' => $calcul,
            );

            $this->Traitement_model->not_lu_recepteur($where_2, $datas);
            // }
        }
    }








    public function Modifier_positon_genera($id_discussion, $emetteur)
    {
        // recuperer et afficher les message dans le pop up

        $this->cors();

        $where_1 = array(
            'id_discussion' => $id_discussion,
        );
        $where_2 = array(
            'emetteur' => $emetteur,
        );
        $where_3 = array(
            'recepteur' => $emetteur,
        );


        $data = $this->Traitement_model->mes_amis_bis($where_1, $where_2, $where_3);

        $index = 0;
        // $total = count($data);

        foreach ($data as $key) {



            if ($key->id_discussion == $id_discussion) {

                $where_id_1 = array(
                    'id' => $key->id,
                );

                $data_position_1 = array(
                    'position' => 0,
                );

                $this->Traitement_model->Modifier_positons($where_id_1, $data_position_1);
            } else {

                $index++;

                $where_id_2 = array(
                    'id' => $key->id,
                );

                $data_position = array(
                    'position' => $index
                );

                $this->Traitement_model->Modifier_positons($where_id_2, $data_position);
            }
        }
    }




    public function Calcul_non_lu_recepteur($id_discussion, $emetteur_msg)
    {

        $this->cors();

        $where_1 = array(
            'id_discussion' => $id_discussion,
            'emetteur_msg' => $emetteur_msg,
        );


        $data = $this->Traitement_model->nos_messages($where_1);
        $nbr = 0;
        foreach ($data as $key) {
            if ($key->view_recepteur == false) {
                $nbr++;
                # code...
            }
        }




        $where_3 = array(
            'id_discussion' => $id_discussion,
        );
        $mesçinfo = $this->Traitement_model->mes_amis($where_3);


        foreach ($mesçinfo as $key) {
            if ($key->emetteur == $emetteur_msg) {

                $where_2 = array(
                    'id_discussion' => $id_discussion,
                );

                $datas = array(
                    'non_lu_recepteur' => $nbr,
                );

                $this->Traitement_model->not_lu_recepteur($where_2, $datas);
            }
            if ($key->recepteur == $emetteur_msg) {

                $where_5 = array(
                    'id_discussion' => $id_discussion,
                );

                $datasss = array(
                    'non_lu_emetteur' => $nbr,
                );

                $this->Traitement_model->not_lu_recepteur($where_5, $datasss);
            }
        }
    }










    public function recuperer_messages()
    {

        $this->cors();

        $type_discussion = $_POST['type_discussion'];

        # code...
        $donnee_0 = array(
            'id_discussion' => $_POST['id_discussion'],
        );

        $les_messages = $this->Traitement_model->nos_messages($donnee_0);


        $this->clear_lu($_POST['id_discussion'], $_POST['emetteur']);


        $resultat = array(
            'resultat' => $les_messages,
        );

        echo json_encode($resultat);


        // recuperer tous les messages

    }







    public function clear_lu($id_discussion, $emetteur)
    {

        $this->cors();


        $where_msg = array(
            'id_discussion' => $id_discussion,
            'recepteur_msg' => $_POST['emetteur'],
        );

        $data_msg = array(
            'view_recepteur' => true,
        );

        $this->Traitement_model->clear_lu_massege($where_msg, $data_msg);








        $where_3 = array(
            'id_discussion' => $id_discussion,
        );
        $mesçinfo = $this->Traitement_model->mes_amis($where_3);


        foreach ($mesçinfo as $key) {
            if ($key->emetteur == $emetteur) {

                $where_2 = array(
                    'id_discussion' => $id_discussion,
                );

                $datas = array(
                    'non_lu_emetteur' => 0,
                );

                $this->Traitement_model->not_lu_recepteur($where_2, $datas);
            }
            if ($key->recepteur == $emetteur) {

                $where_5 = array(
                    'id_discussion' => $id_discussion,
                );

                $datasss = array(
                    'non_lu_recepteur' => 0,
                );

                $this->Traitement_model->not_lu_recepteur($where_5, $datasss);
            }
        }
    }





    public function recuperer_messages_groupe()
    {

        $this->cors();


        # code...
        $donnee_0 = array(
            'nom_groupe' => $_POST['nom_groupe'],
        );

        $les_messages = $this->Traitement_model->nos_messages_groupe($donnee_0);


        // recuperer les membre du groupe
        $donnee_10 = array(
            'recepteur' => $_POST['nom_groupe'],
        );



        $this->clear_lu_groupe($_POST['nom_groupe'], $_POST['emetteur']);


        $resultat = array(
            'resultat' => $les_messages,
            'membre_du_groupe' => $this->Traitement_model->mes_amis($donnee_10),
            'all_user' => $this->Traitement_model->all_user(),
        );

        echo json_encode($resultat);
    }








    public function clear_lu_groupe($nom_groupe, $emetteur)
    {

        $this->cors();





        $donnee_1 = array(
            'nom_groupe' => $nom_groupe,
            'emetteur_msg' => $emetteur,
        );

        $donnee_10 = array(
            'lu' => true,
        );

        $this->Traitement_model->clear_lu_massege_groupe($donnee_1, $donnee_10);





        $where_2 = array(
            'recepteur' => $nom_groupe,
            'emetteur' =>  $emetteur
        );

        $datas = array(
            'non_lu_emetteur' => 0,
        );

        $this->Traitement_model->not_lu_recepteur($where_2, $datas);
    }









    public function liste_utilistaeur()
    {
        # code...

        $this->cors();
        $where = array(
            'recepteur' => $_POST['nom_groupe'],
        );


        $resultat = array(
            'all_users' => $this->Traitement_model->all_user(),
            'membre_du_groupe' =>  $this->Traitement_model->mes_amis($where)
        );


        echo json_encode($resultat);
    }





    public function les_membre_du_groupe()
    {
        # code...

        $this->cors();
        $donnee_10 = array(
            'recepteur' =>  $_POST['nom_group'],
        );


        $resultat = array(
            'all_users' => $this->Traitement_model->all_user(),
            'les_membres' => $this->Traitement_model->mes_amis($donnee_10)
        );

        echo json_encode($resultat);
    }





    public function delete_from_group()
    {
        # code...
        $this->cors();
        $donnee_10 = array(
            'id' =>  $_POST['id'],
        );

        $this->Traitement_model->delete_çfrom_group($donnee_10);





        $donnee_1 = array(
            'last_message' => date('H:i')
        );

        $this->Traitement_model->ajouter_amis($donnee_1);


        $resultat = array(
            'resultat' => 'save'
        );

        echo json_encode($resultat);
    }






    public function info_groupe()
    {
        # code...
        $this->cors();
        $donnee_1 = array(
            'pseudo' => $_POST['nom_groupe'],
        );

        $resultat = array(
            'resultat' =>   $this->Traitement_model->information_personnel($donnee_1)
        );

        echo json_encode($resultat);
    }







    public function update_info_groupe()
    {
        # code...
        $this->cors();
        if ($_POST['action'] == "modifier_image") {
            # code...
            if (isset($_FILES['image']['name'])) {

                $config['upload_path'] = './fichiers/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4';
                $config['encrypt_name']        = true;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('image')) {
                    echo 'error';
                } else {

                    $Nom_fichier = $this->upload->data('file_name');


                    $donnee = array(
                        'profile' =>  $Nom_fichier,
                    );

                    $where = array(
                        'pseudo' => $_POST['initail_pseudo'],
                    );


                    $this->Traitement_model->update_nfo_perso($where, $donnee);

                    ///   send notification

                    $resultat = array(
                        'resultat' => 'save',
                        'source' => 'modifier image',
                    );

                    echo json_encode($resultat);
                }

                // ########################
            }
        }




        if ($_POST['action'] == "modifier_image_et_nom") {
            # code...

            $donnee = array(
                'pseudo' => $_POST['pseudo'],
            );


            $count_0 = $this->Traitement_model->Check_user($donnee);


            if ($count_0 == 0) {



                if (isset($_FILES['image']['name'])) {

                    $config['upload_path'] = './fichiers/';
                    $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4';
                    $config['encrypt_name']        = true;
                    $this->load->library('upload', $config);

                    if (!$this->upload->do_upload('image')) {
                        echo 'error';
                    } else {

                        $Nom_fichier = $this->upload->data('file_name');


                        $donnee = array(
                            'profile' =>  $Nom_fichier,
                            'pseudo' => $_POST['pseudo'],
                        );

                        $where = array(
                            'pseudo' => $_POST['initail_pseudo'],
                        );


                        $this->Traitement_model->update_nfo_perso($where, $donnee);

                        ///   modifier nom_grope partout



                        // les base : lu_message_groupe -> nom_groupe

                        $where_20 = array(
                            'nom_groupe' => $_POST['initail_pseudo'],
                        );

                        $donnee_20 = array(
                            'nom_groupe' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_base_non_lu($where_20, $donnee_20);



                        // les base : message_groupe -> nom_groupe

                        $where_21 = array(
                            'nom_groupe' => $_POST['initail_pseudo'],
                        );

                        $donnee_21 = array(
                            'nom_groupe' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_message_groupe($where_21, $donnee_21);

                        // les base : mes_amis -> recepteur


                        $where_22 = array(
                            'recepteur' => $_POST['initail_pseudo'],
                        );

                        $donnee_22 = array(
                            'recepteur' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_mes_amis($where_22, $donnee_22);






                        $resultat = array(
                            'resultat' => 'save',
                            'source' => 'modifier_image_et_nom',
                        );

                        echo json_encode($resultat);
                    }

                    // ########################
                }
            } else {
                $resultat = array(
                    'resultat' => 'user_found'
                );

                echo json_encode($resultat);
            }
        }


        if ($_POST['action'] == "modifier_nom") {
            # code...

            $donnee = array(
                'pseudo' => $_POST['pseudo'],
            );


            $count_1 = $this->Traitement_model->Check_user($donnee);


            if ($count_1 == 0) {

                $where = array(
                    'pseudo' => $_POST['initail_pseudo'],
                );
                $donnees = array(
                    'pseudo' => $_POST['pseudo'],
                );

                $this->Traitement_model->update_nfo_perso($where, $donnees);

                ///   modifier nom_grope partout



                // les base : lu_message_groupe -> nom_groupe

                $where_20 = array(
                    'nom_groupe' => $_POST['initail_pseudo'],
                );

                $donnee_20 = array(
                    'nom_groupe' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_base_non_lu($where_20, $donnee_20);



                // les base : message_groupe -> nom_groupe

                $where_21 = array(
                    'nom_groupe' => $_POST['initail_pseudo'],
                );

                $donnee_21 = array(
                    'nom_groupe' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_message_groupe($where_21, $donnee_21);

                // les base : mes_amis -> recepteur


                $where_22 = array(
                    'recepteur' => $_POST['initail_pseudo'],
                );

                $donnee_22 = array(
                    'recepteur' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_mes_amis($where_22, $donnee_22);



                $resultat = array(
                    'resultat' => 'save',
                    'source' => 'modifier_nom',
                );

                echo json_encode($resultat);
            } else {
                $resultat = array(
                    'resultat' => 'user_found'
                );

                echo json_encode($resultat);
            }
        }
    }





    public function delete_groupe()
    {
        # code...

        $this->cors();

        $where = array(
            'pseudo' => $_POST['initail_pseudo'],
        );


        $this->Traitement_model->delete_nfo_utilisateur($where);

        ///   modifier nom_grope partout



        // les base : lu_message_groupe -> nom_groupe

        $where_20 = array(
            'nom_groupe' => $_POST['initail_pseudo'],
        );



        $this->Traitement_model->delete_base_non_lu($where_20);



        // les base : message_groupe -> nom_groupe

        $where_21 = array(
            'nom_groupe' => $_POST['initail_pseudo'],
        );




        $this->Traitement_model->delete_message_groupe($where_21);

        // les base : mes_amis -> recepteur


        $where_22 = array(
            'recepteur' => $_POST['initail_pseudo'],
        );




        $this->Traitement_model->delete_mes_amis($where_22);



        $resultat = array(
            'resultat' => 'save',
        );

        echo json_encode($resultat);
    }






    public function mes_infos()
    {
        $this->cors();
        # code...
        $donnee_1 = array(
            'pseudo' => $_POST['pseudo'],
        );

        $resultat = array(
            'resultat' =>   $this->Traitement_model->information_personnel($donnee_1)
        );

        echo json_encode($resultat);
    }








    public function update_info_PERSO()
    {
        # code...
        $this->cors();
        if ($_POST['action'] == "modifier_image") {
            # code...
            if (isset($_FILES['image']['name'])) {

                $config['upload_path'] = './fichiers/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4';
                $config['encrypt_name']        = true;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('image')) {
                    echo 'error';
                } else {

                    $Nom_fichier = $this->upload->data('file_name');


                    $donnee = array(
                        'profile' =>  $Nom_fichier,
                    );

                    $where = array(
                        'pseudo' => $_POST['initail_pseudo'],
                    );


                    $this->Traitement_model->update_nfo_perso($where, $donnee);

                    ///   send notification

                    $resultat = array(
                        'resultat' => 'save',
                        'source' => 'modifier image',
                    );

                    echo json_encode($resultat);
                }

                // ########################
            }
        }




        if ($_POST['action'] == "modifier_image_et_nom") {
            # code...

            $donnee = array(
                'pseudo' => $_POST['pseudo'],
            );


            $count_0 = $this->Traitement_model->Check_user($donnee);


            if ($count_0 == 0) {



                if (isset($_FILES['image']['name'])) {

                    $config['upload_path'] = './fichiers/';
                    $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4';
                    $config['encrypt_name']        = true;
                    $this->load->library('upload', $config);

                    if (!$this->upload->do_upload('image')) {
                        echo 'error';
                    } else {

                        $Nom_fichier = $this->upload->data('file_name');


                        $donnee = array(
                            'profile' =>  $Nom_fichier,
                            'pseudo' => $_POST['pseudo'],
                        );

                        $where = array(
                            'pseudo' => $_POST['initail_pseudo'],
                        );


                        $this->Traitement_model->update_nfo_perso($where, $donnee);

                        ///   modifier nom_grope partout



                        // les base : lu_message_groupe -> nom_groupe

                        $where_20 = array(
                            'emetteur_msg' => $_POST['initail_pseudo'],
                        );

                        $donnee_20 = array(
                            'emetteur_msg' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_base_non_lu($where_20, $donnee_20);



                        // les base : message_groupe -> nom_groupe

                        $where_21 = array(
                            'emetteur_msg' => $_POST['initail_pseudo'],
                        );

                        $donnee_21 = array(
                            'emetteur_msg' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_message_groupe($where_21, $donnee_21);

                        // les base : mes_amis -> recepteur



                        $where_22 = array(
                            'recepteur' => $_POST['initail_pseudo'],
                        );

                        $donnee_22 = array(
                            'recepteur' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_mes_amis($where_22, $donnee_22);






                        $where_23 = array(
                            'emetteur' => $_POST['initail_pseudo'],
                        );

                        $donnee_23 = array(
                            'emetteur' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_mes_amis($where_23, $donnee_23);



                        //########################




                        // les base : messages -> emetteur_msg  recepteur_msg



                        $where_24 = array(
                            'emetteur_msg' => $_POST['initail_pseudo'],
                        );

                        $donnee_24 = array(
                            'emetteur_msg' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_mesages($where_24, $donnee_24);






                        $where_25 = array(
                            'recepteur_msg' => $_POST['initail_pseudo'],
                        );

                        $donnee_25 = array(
                            'recepteur_msg' =>   $_POST['pseudo'],
                        );


                        $this->Traitement_model->update_mesages($where_25, $donnee_25);



                        //########################







                        $resultat = array(
                            'resultat' => 'save',
                            'source' => 'modifier_image_et_nom',
                        );

                        echo json_encode($resultat);
                    }

                    // ########################
                }
            } else {
                $resultat = array(
                    'resultat' => 'user_found'
                );

                echo json_encode($resultat);
            }
        }


        if ($_POST['action'] == "modifier_nom") {
            # code...

            $donnee = array(
                'pseudo' => $_POST['pseudo'],
            );


            $count_1 = $this->Traitement_model->Check_user($donnee);


            if ($count_1 == 0) {

                $where = array(
                    'pseudo' => $_POST['initail_pseudo'],
                );
                $donnees = array(
                    'pseudo' => $_POST['pseudo'],
                );

                $this->Traitement_model->update_nfo_perso($where, $donnees);

                ///   modifier nom_grope partout



                // les base : lu_message_groupe -> nom_groupe

                $where_20 = array(
                    'emetteur_msg' => $_POST['initail_pseudo'],
                );

                $donnee_20 = array(
                    'emetteur_msg' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_base_non_lu($where_20, $donnee_20);



                // les base : message_groupe -> nom_groupe

                $where_21 = array(
                    'emetteur_msg' => $_POST['initail_pseudo'],
                );

                $donnee_21 = array(
                    'emetteur_msg' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_message_groupe($where_21, $donnee_21);

                // les base : mes_amis -> recepteur



                $where_22 = array(
                    'recepteur' => $_POST['initail_pseudo'],
                );

                $donnee_22 = array(
                    'recepteur' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_mes_amis($where_22, $donnee_22);






                $where_23 = array(
                    'emetteur' => $_POST['initail_pseudo'],
                );

                $donnee_23 = array(
                    'emetteur' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_mes_amis($where_23, $donnee_23);



                //########################




                // les base : messages -> emetteur_msg  recepteur_msg



                $where_24 = array(
                    'emetteur_msg' => $_POST['initail_pseudo'],
                );

                $donnee_24 = array(
                    'emetteur_msg' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_mesages($where_24, $donnee_24);






                $where_25 = array(
                    'recepteur_msg' => $_POST['initail_pseudo'],
                );

                $donnee_25 = array(
                    'recepteur_msg' =>   $_POST['pseudo'],
                );


                $this->Traitement_model->update_mesages($where_25, $donnee_25);



                //########################





                $resultat = array(
                    'resultat' => 'save',
                    'source' => 'modifier_nom',
                );

                echo json_encode($resultat);
            } else {
                $resultat = array(
                    'resultat' => 'user_found'
                );

                echo json_encode($resultat);
            }
        }
    }






    public function update_role_user()
    {
        # code...
        $this->cors();

        $donnee = array(
            'role' =>  $_POST['role'],
        );

        $where = array(
            'id' => $_POST['id'],
        );


        $this->Traitement_model->update_nfo_perso($where, $donnee);

        ///   send notification

        $resultat = array(
            'resultat' => 'save',
            'source' => 'modifier image',
        );

        echo json_encode($resultat);
    }


    public function FunctionName()
    {
        # code...
        $stock_image = array();

        $nbr_fichier = count($_FILES['fichier']['name']);

        for ($i = 0; $i < $nbr_fichier; $i++) {
            $_FILES['file']['name'] = $_FILES['fichier']['name'][$i];
            $_FILES['file']['type'] = $_FILES['fichier']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['fichier']['tmp_name'][$i];
            $_FILES['file']['size'] = $_FILES['fichier']['size'][$i];

            $config['upload_path'] = './fichiers/';
            $config['allowed_types']        = 'jpg|png|jpeg|gif|pdf|doc|docx';
            $config['encrypt_name']        = true;

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload('file')) {

                $Nom_fichier = $this->upload->data('file_name');
                array_push($stock_image, $Nom_fichier);
            }
        }

        $data_message = array();

        for ($i = 0; $i < count($stock_image); $i++) {
            $data_message['image_msg_' . $i . ''] = $stock_image[$i];
        }
    }



    public function delete_message()
    {
        # code...
        $this->cors();

        $type = $_POST['type'];

        if ($type == 'user') {
            # code...
            $where = array(
                'id' => $_POST['id'],
            );
            $this->Traitement_model->delete_message_user($where);

            $resultat = array(
                'resultat' => 'save',
            );

            echo json_encode($resultat);
        }

        if ($type == 'groupe') {
            # code...
            $where = array(
                'id' => $_POST['id'],
            );
            $this->Traitement_model->delete_message_groupe($where);

            $resultat = array(
                'resultat' => 'save',
            );

            echo json_encode($resultat);
        }


        ///   modifier nom_grope partout



    }


    // ##################################
}