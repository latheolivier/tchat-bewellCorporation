<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Messages extends CI_Controller
{


	public function index()
	{
		$this->load->view('welcome_message');
	}


	public function cors()
	{
		header("Access-Control-Allow-Origin: *");

		header("Access-Control-Allow-Headers: Authorization, Content-Type");

		header('content-type: application/json; charset=utf-8');
	}





	public function Check_user()
	{
		$this->cors();

		$donnee = array(
			'user_name' => $_POST['user_name'],
		);

		$count = $this->Traitement_model->Check_user($donnee);

		if ($count == 0) {
			$resultat = array(
				'resultat' => 'not_found'
			);
			echo json_encode($resultat);
		}
		if ($count > 0) {
			$this->Recuperer_all_discussion($_POST['user_name']);
		}
	}






	public function Recuperer_all_discussion($user_name)
	{
		$this->cors();
		$where_1 = array(
			'user_name' => $user_name,
		);


		$data = $this->Traitement_model->Recuperer_all_discussion($where_1);

		$resultat = array(
			'resultat' => $data
		);

		echo json_encode($resultat);
	}






	//  function ajout de message et de creation de compte si possible


	public function Add_message()
	{

		$this->cors();

		$donnee = array(
			'user_name' => $_POST['user_name'],
		);

		$count = $this->Traitement_model->Check_user($donnee);


		if ($count == 0) {

			// add uer
			$nombre_total = $this->Traitement_model->Count_user();

			$donnee_user = array(
				'user_name' => $_POST['user_name'],
				'first_name' => $_POST['first_name'],
				'last_name' => $_POST['last_name'],
				'img_user' => $_POST['img_user'],

			);
			$this->Traitement_model->Add_user($donnee_user);


			// add admin

			// $nombre_total_2 = $this->Traitement_model->Count_user();

			// $donnee_user = array(
			//     'user_name' => "admin_apefa",
			//     'img_listing' => $_POST['img_listing'],
			// );
			// $this->Traitement_model->Add_user($donnee_user);



			//  add message



			$donnee_message = array(
				'user_name' => $_POST['user_name'],
				'message' => $_POST['message'],
				'image_message' => $_POST['image_message'],
				'emetteur' => $_POST['user_name'],
				'view_emetteur' => true,
				'view_recepteur' => false,
				'dates' =>  date('H:i')

			);



			$this->Traitement_model->Add_message($donnee_message);



			//  add last message



			$where_last_1 = array(
				'user_name' => $_POST['user_name'],
			);

			$last_msg_user = array(
				'last_message' => $_POST['message'],
				'dates_last_msg' => date('Y-m-d H:i:s'),
			);



			$this->Traitement_model->Add_last_msg($where_last_1, $last_msg_user);


			//  recuperation de dernnier mesage


			//############################################
			$resultat = array(
				'resultat' => 'not_found'
			);
			echo json_encode($resultat);



			$this->Calcul_non_lu_admin($_POST['user_name']);

			$this->Modifier_positon_genera($_POST['user_name']);
		}



		if ($count > 0) {



			$donnee_message = array(
				'user_name' => $_POST['user_name'],
				'message' => $_POST['message'],
				'image_message' => $_POST['image_message'],
				'emetteur' => $_POST['user_name'],
				'view_emetteur' => true,
				'view_recepteur' => false,
				'dates' => date('H:i'),
			);

			$this->Traitement_model->Add_message($donnee_message);



			//  add last message

			$where_last_1 = array(
				'user_name' => $_POST['user_name'],
			);

			$last_msg_user = array(
				'last_message' => $_POST['message'],
				'dates_last_msg' => date('Y-m-d H:i:s'),
			);



			$this->Traitement_model->Add_last_msg($where_last_1, $last_msg_user);


			//############################################


			$resultat = array(
				'resultat' => 'not_found'
			);
			echo json_encode($resultat);



			$this->Calcul_non_lu_admin($_POST['user_name']);

			$this->Modifier_positon_genera($_POST['user_name']);
		}

		// echo json_encode($resultat);
	}





	public function Calcul_non_lu_admin($user_name)
	{

		$this->cors();

		$where_1 = array(
			'user_name' => $user_name,
		);


		$data = $this->Traitement_model->Recuperer_all_discussion($where_1);
		$nbr = 0;
		foreach ($data as $key) {
			if ($key->view_recepteur == false) {
				$nbr++;
				# code...
			}
		}


		$datas = array(
			'non_lu_admin' => $nbr,
		);

		$this->Traitement_model->not_lu_admin($where_1, $datas);
	}




	public function Modifier_positon_genera($user_name)
	{
		// recuperer et afficher les message dans le pop up

		$this->cors();

		$data = $this->Traitement_model->Recuperer_all_pour_admin();

		$index = 0;
		// $total = count($data);

		foreach ($data as $key) {

			$index++;

			if ($key->user_name == $user_name) {

				$where_id_1 = array(
					'id' => $key->id,
				);

				$data_position_1 = array(
					'all_position' => 0,
				);

				$this->Traitement_model->Modifier_positon($where_id_1, $data_position_1);
			} else {

				$where_id_2 = array(
					'id' => $key->id,
				);

				$data_position = array(
					'all_position' => $index
				);

				$this->Traitement_model->Modifier_positon($where_id_2, $data_position);
			}
		}
	}











	public function Message_per_user()
	{

		$this->cors();

		$where_1 = array(
			'user_name' => $_POST['user_name'],
		);


		$data = $this->Traitement_model->Recuperer_all_discussion($where_1);

		$resultat = array(
			'resultat' => $data
		);

		echo json_encode($resultat);




		$this->Clear_non_lu_user($_POST['user_name']);
	}







	public function Clear_non_lu_user($user_name)
	{

		$this->cors();
		$where_1 = array(
			'user_name' => $user_name,
			'emetteur' => 'admin_apefa',
		);

		$datas = array(
			'view_emetteur' => true,
		);

		$this->Traitement_model->Clear_non_lu_user($where_1, $datas);


		$where_3 = array(
			'user_name' => $user_name,
		);

		$datassss = array(
			'non_lu_user' => 0,
		);

		$this->Traitement_model->not_lu_admin($where_3, $datassss);
	}








	public function Mes_discussons()
	{

		$this->cors();

		$donee = array(
			'user_name' => $_POST['user_name'],
		);


		$data = $this->Traitement_model->Mes_discussons($donee);
		// $ùessage = $this->Traitement_model->Mes_messages($donee);

		$resultat = array(
			'resultat' => $data,
		);

		echo json_encode($resultat);
	}










	public function Count_non_lu_user()
	{
		$this->cors();

		$donee = array(
			'user_name' => $_POST['user_name'],
		);


		$data = $this->Traitement_model->Count_non_lu_user($donee);
		// $ùessage = $this->Traitement_model->Mes_messages($donee);

		$resultat = array(
			'resultat' => $data,
		);

		echo json_encode($resultat);
	}







	public function Delete_user_message()
	{


		$this->cors();

		$donee = $_POST['id'];

		$data = $this->Traitement_model->Delete_user_message($donee);

		$resultat = array(
			'resultat' => "delete",
		);

		echo json_encode($resultat);
	}

















































	public function Message_per_user_admin()
	{

		$this->cors();

		$where_1 = array(
			'user_name' => $_POST['user_name'],
		);


		$data = $this->Traitement_model->Recuperer_all_discussion($where_1);

		$resultat = array(
			'resultat' => $data
		);

		echo json_encode($resultat);



		$this->Calcul_non_lu_user($_POST['user_name']);
		$this->Clear_non_lu_admin($_POST['user_name']);
	}






	public function Calcul_non_lu_user($user_name)
	{

		$this->cors();

		$where_1 = array(
			'user_name' => $user_name,
		);


		$data = $this->Traitement_model->Recuperer_all_discussion($where_1);
		$nbr = 0;
		foreach ($data as $key) {
			if ($key->view_emetteur == false) {
				$nbr++;
				# code...
			}
		}


		$datas = array(
			'non_lu_user' => $nbr,
		);

		$this->Traitement_model->not_lu_admin($where_1, $datas);
	}





	public function Clear_non_lu_admin($user_name)
	{

		$this->cors();

		$where_1 = array(
			'user_name' => $user_name,
			// 'emetteur' => 'admin_apefa',
		);

		$datas = array(
			'view_recepteur' => true,
		);

		$this->Traitement_model->Clear_non_lu_user($where_1, $datas);



		$where_3 = array(
			'user_name' => $user_name,
		);

		$datassss = array(
			'non_lu_admin' => 0,
		);

		$this->Traitement_model->not_lu_admin($where_3, $datassss);
	}






	public function Admin_add_message()
	{

		$this->cors();



		$donnee_message = array(
			'user_name' => $_POST['user_name'],
			'message' => $_POST['message'],
			'emetteur' => "admin_apefa",
			'view_emetteur' => false,
			'view_recepteur' => true,
			'dates' => date('H:i'),
		);

		$this->Traitement_model->Add_message($donnee_message);



		//  add last message

		$where_last_1 = array(
			'user_name' => $_POST['user_name'],
		);

		$last_msg_user = array(
			'last_message' => $_POST['message'],
			'dates_last_msg' => date('Y-m-d H:i:s'),
		);



		$this->Traitement_model->Add_last_msg($where_last_1, $last_msg_user);



		$resultat = array(
			'resultat' => 'save'
		);

		echo json_encode($resultat);



		$this->Modifier_positon_genera($_POST['user_name']);

		$this->Calcul_non_lu_user($_POST['user_name']);
		$this->Clear_non_lu_admin($_POST['user_name']);
	}




	public function All_message_admin()
	{

		$this->cors();

		$data = $this->Traitement_model->Recuperer_all_pour_admin();

		$resultat = array(
			'resultat' => $data
		);

		echo json_encode($resultat);
	}













	// #################################################################""
	// #################################################################""
	//             traitement  listing user
	//   #################################################################""
	//  #################################################################""







	public function Add_listing()
	{

		$this->cors();

		$donnee_message = array(
			'user_name' => $_POST['user_name'],
			'id_2' => $_POST['id_2'],

		);

		$this->Traitement_model->Add_listing($donnee_message);


		$resultat = array(
			'resultat' => 'save'
		);

		echo json_encode($resultat);
	}







	public function My_listing()
	{

		$this->cors();

		$where_1 = array(
			'user_name' => $_POST['user_name'],
		);


		$data = $this->Traitement_model->My_listing($where_1);

		$resultat = array(
			'resultat' => $data
		);

		echo json_encode($resultat);
	}





	// #################################################
}