<?php
if (!defined('BASEPATH')) exit('No direct script accessallowed');

class Traitement_model extends CI_Model
{

    /*
##########################################################################################
                           les tables
##########################################################################################

*/

    // nom de la base de donnee    chat_bewell

    protected $table_user_listing = 'user_listing';




    protected $table_utilisateurs = 'utilisateurs';
    protected $invitations = 'invitations';
    protected $mes_amis = 'mes_amis';
    protected $table_messages = 'messages';
    protected $messages_groupe = 'messages_groupe';
    protected $lu_message_groupe = 'lu_message_groupe';




    // 


    /*
##########################################################################################
                           TRAITEMENT DES INFIRMATION
##########################################################################################

*/



    // nombre total user

    public function Count_user()
    {
        $etat = (int) $this->db->count_all_results($this->table_utilisateurs);

        return $etat;
    }


    // verification des information de l'utilisteur

    public function Check_user($donnee)
    {
        $etat = (int) $this->db->where($donnee)
            ->count_all_results($this->table_utilisateurs);

        return $etat;
    }

    //  creer un utilisateur

    public function Add_user($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->table_utilisateurs);
    }




    public function information_personnel($where_1)
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            ->where($where_1)
            ->get()
            ->result();
    }




    public function all_user()
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            ->get()
            ->result();
    }


    public function update_nfo_perso($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_utilisateurs);
    }




    public function verifier_invitation($donnee)
    {
        $etat = (int) $this->db->where($donnee)
            ->count_all_results($this->invitations);

        return $etat;
    }




    public function add_invitation($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->invitations);
    }



    public function mes_invitation($donnee_0)
    {
        return $this->db->select('*')
            ->from($this->invitations)
            ->where($donnee_0)
            ->get()
            ->result();
    }







    public function valider_invitation($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->invitations);
    }



    public function ajouter_amis($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->mes_amis);
    }



    public function mes_amis($donnee_3)
    {
        return $this->db->select('*')
            ->from($this->mes_amis)
            ->where($donnee_3)
            ->get()
            ->result();
    }




    public function mes_amis_2($donnee_0, $donnee_1)
    {


        return $this->db->select('*')
            ->from($this->mes_amis)
            ->where($donnee_0)
            ->or_where($donnee_1)
            ->order_by('position', 'desc')
            ->get()
            ->result();
    }


    public function mes_amis_bis($where_1, $where_2, $where_3)
    {

        return $this->db->select('*')
            ->from($this->mes_amis)
            ->where($where_1)
            ->or_where($where_2)
            ->or_where($where_3)
            ->get()
            ->result();
    }


    public function toal_amis()
    {
        $etat = (int) $this->db
            ->count_all_results($this->mes_amis);

        return $etat;
    }



    public function nos_messages($donnee_3)
    {
        return $this->db->select('*')
            ->from($this->table_messages)
            ->where($donnee_3)
            ->get()
            ->result();
    }


    public function nos_messages_groupe($donnee_3)
    {
        return $this->db->select('*')
            ->from($this->messages_groupe)
            ->where($donnee_3)
            ->get()
            ->result();
    }



    public function all_messages()
    {
        return $this->db->select('*')
            ->from($this->table_messages)
            ->get()
            ->result();
    }






    public function send_messages($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->table_messages);
    }





    public function add_lu_groupe($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->lu_message_groupe);
    }



    public function select_lu_groupe($donnee_3)
    {

        $etat = (int) $this->db->where($donnee_3)
            ->count_all_results($this->lu_message_groupe);

        return $etat;
    }




    public function send_messages_groupe($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->messages_groupe);
    }


    public function not_lu_recepteur($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->mes_amis);
    }




    public function clear_lu_massege($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_messages);
    }



    public function clear_lu_massege_groupe($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->lu_message_groupe);
    }




    public function Modifier_positons($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->mes_amis);
    }





    public function delete_çfrom_group($where)
    {
        return $this->db->where($where)
            ->delete($this->mes_amis);
    }




    public function update_base_non_lu($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->lu_message_groupe);
    }

    public function update_message_groupe($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->messages_groupe);
    }

    public function update_mes_amis($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->mes_amis);
    }



    public function update_mesages($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_messages);
    }




    public function delete_nfo_utilisateur($where)
    {
        return $this->db->where($where)
            ->delete($this->table_utilisateurs);
    }






    public function delete_base_non_lu($where)
    {
        return $this->db->where($where)
            ->delete($this->lu_message_groupe);
    }




    public function delete_message_groupe($where)
    {
        return $this->db->where($where)
            ->delete($this->messages_groupe);
    }



    public function delete_mes_amis($where)
    {
        return $this->db->where($where)
            ->delete($this->mes_amis);
    }





    public function delete_message_user($where)
    {
        return $this->db->where($where)
            ->delete($this->table_messages);
    }



























































    //  creer un utilisateur

    public function Add_message($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->table_messages);
    }





    /**
     * recuperer tous les discussion
     */

    public function Recuperer_all_discussion($where_1)
    {
        return $this->db->select('*')
            ->from($this->table_messages)
            ->where($where_1)
            ->order_by('id', 'desc')
            ->get()
            ->result();
    }



















    /**
     * recuperer tous les discussion
     */

    public function Recuperer_all_pour_admin()
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            // ->order_by('position', 'asc')
            ->get()
            ->result();
    }




    /**
     * recuperer tous mes discussion
     */

    public function Mes_discussons($donee)
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            ->where($donee)
            // ->order_by('position', 'asc')
            ->get()
            ->result();
    }



    /**
     * recuperer tous mes discussion
     */

    public function Count_non_lu_user($donee)
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            ->where($donee)
            // ->order_by('position', 'asc')
            ->get()
            ->result();
    }


    public function Mes_messages($donee)
    {
        return $this->db->select('*')
            ->from($this->table_messages)
            ->where($donee)
            // ->order_by('position', 'asc')
            ->get()
            ->result();
    }



    public function Add_last_msg($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_utilisateurs);
    }





    public function Modifier_positon($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_utilisateurs);
    }




    public function not_lu_admin($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_utilisateurs);
    }





    public function Clear_non_lu_user($wher, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where($wher);
        return $this->db->update($this->table_messages);
    }



    public function Delete_user_message($id)
    {
        return $this->db->where('id', (int) $id)
            ->delete($this->table_messages);
    }







    public function Add_listing($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->table_user_listing);
    }



    public function My_listing($donee)
    {
        return $this->db->select('*')
            ->from($this->table_user_listing)
            ->where($donee)
            ->order_by('id', 'desc')
            ->get()
            ->result();
    }

































































    // verification de email et mot de passe

    public function login($donnee)
    {
        $etat = (int) $this->db->where($donnee)
            ->count_all_results($this->table_utilisateurs);

        return $etat;
    }


    // modifieremail

    public function modifier_email($donnee, $id)
    {
        $this->db->set($donnee);
        $this->db->where('id', (int) $id);
        return $this->db->update($this->table_utilisateurs);
    }


    // modifier  mot de passe


    public function modifier_mot_de_passe($email, $donnee)
    {
        $this->db->set($donnee);
        $this->db->where('email',  $email);
        return $this->db->update($this->table_utilisateurs);
    }







    // verification de numero

    public function verifier_numero($donnee)
    {
        $etat = (int) $this->db->where($donnee)
            ->count_all_results($this->table_utilisateurs);

        return $etat;
    }

    /**
     * verification du verifier_username
     */
    public function verifier_username($donnee)
    {
        $etat = (int) $this->db->where($donnee)
            ->count_all_results($this->table_utilisateurs);

        return $etat;
    }

    /**
     * donnee des utilisateur
     */
    public function user_data($donnee)
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            ->where($donnee)
            ->get()
            ->result();
    }



    /**
     * fonction affichage 1 seul domaine
     */
    public function ajouter_via_google($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->table_utilisateurs);
    }

    public function delete_user($id)
    {
        return $this->db->where('id', (int) $id)
            ->delete($this->table_utilisateurs);
    }

    /**
     * supprimer  les annonces
     */
    public function ajouter_via_numero($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->table_utilisateurs);
    }



    // #################################################################""
    // #################################################################""
    //             traitement  des notifications
    //   #################################################################""
    //  #################################################################""



    public function verifier_data_post($id)
    {

        $etat = (int) $this->db->where('id_2',  $id)
            ->count_all_results($this->Post_notifications);
        return $etat;
    }


    public function insert_notification($donnee)
    {
        return $this->db
            ->set($donnee)
            ->insert($this->Post_notifications);
    }


    /**
     * recuperer donnees post notification
     */
    public function post_for_notification($donnee)
    {
        return $this->db->select('*')
            ->from($this->Post_notifications)
            ->where($donnee)
            ->get()
            ->result();
    }



    public function ajouter_token($donnee, $id)
    {
        $this->db->set($donnee);
        $this->db->where('id', (int) $id);
        return $this->db->update($this->table_utilisateurs);
    }



    public function all_token()
    {
        return $this->db->select('*')
            ->from($this->table_utilisateurs)
            ->get()
            ->result();
    }



    public function all_notifications()
    {
        return $this->db->select('*')
            ->from($this->Post_notifications)
            ->get()
            ->result();
    }
    // ********************************************
}