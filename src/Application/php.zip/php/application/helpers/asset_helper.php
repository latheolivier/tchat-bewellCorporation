<?php
defined('BASEPATH') or exit('No direct script access allowed');


/***************************************************
 *    helper formulaire
 * ************************************************
 */

function url_helper($nom)
{
    return base_url() . $nom;
}


/***************************************************
 *    helper formulaire
 * ************************************************
 */

function url_helper_boutique($nom)
{
    return base_url() . "assets/boutique/" . $nom;
}
