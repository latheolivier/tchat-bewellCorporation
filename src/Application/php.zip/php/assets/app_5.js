$(document).ready(function () {
    les_data();
    // alert('hbgb')
});



const URL = 'http://localhost/messages/Messages'

var BASE_USER = Array()  //  base de donnne des utilisateur
var BASE_DISCUSSION = Array()  //  base de donnne de discussion
var LISTING_IDS = Array()  //  variable listing -> int
var USER_NAMES = Array()  //  variable user_name -> string
var ID_SELECT = Array()  //  variable id user selectionner -> int


var TITLE_HEADER = Array()  //  variable id user selectionner -> int
var IMAGE_HEADER = Array()  //  variable id user selectionner -> int


var INTERVAL_MESSAGE_DISPLAY = setInterval(() => {
    Les_messages()
}, 2000);


var INTERVAL_USER_DISPLAY = setInterval(() => {
    les_data()
}, 2000);



function compare() {

    // Les_states.all_annonce.sort((a, b) => a.endroit - b.endroit)

    let base_online = [
        {
            id: 1,
            nom: 'hippo'
        },

        {
            id: 2,
            nom: 'hippo'
        },
        {
            id: 3,
            nom: 'hippo'
        }

    ]


    let base_local = [{
        id: 1,
        nom: 'hippo'
    }]

    let result = base_online.filter(o1 => !base_local.some(o2 => o1.id === o2.id));

    console.log(result)

}



function Cut_word(phraes) {
    if (phraes.length > 20) {
        let cut = phraes.substring(0, 20) + '...';
        return cut
    }
    else return phraes
}




function les_data() {

    fetch("" + URL + "/All_message_admin", {
        method: "POST",
    })
        .then((response) => response.json())
        .then((response) => {

            if (response.resultat.length > 0) {

                if (BASE_USER.length > 0) {


                    let recherche = response.resultat.filter(o1 => !BASE_USER.some(o2 => o1.non_lu_admin === o2.non_lu_admin));

                    if (recherche.length > 0) {
                        BASE_USER = []
                        response.resultat.forEach(element_reche => {
                            BASE_USER.push(element_reche)
                        });

                        Afficher_user()
                    }


                    let recherche_2 = response.resultat.filter(o1 => !BASE_USER.some(o2 => o1.last_message === o2.last_message));

                    if (recherche_2.length > 0) {
                        BASE_USER = []
                        response.resultat.forEach(element_reche => {
                            BASE_USER.push(element_reche)
                        });

                        Afficher_user()
                    }



                }
                else {


                    response.resultat.forEach(element_b => {
                        BASE_USER.push(element_b)
                    });

                    Afficher_user()
                }


            }






        })
        .catch((error) => {
            console.log(error)
        });

}






function Afficher_user() {


    document.getElementById('les_discussions').innerHTML = ''

    BASE_USER.sort((a, b) => a.all_position - b.all_position).forEach(element => {

        IMAGE_HEADER[0] = element.img_user
        TITLE_HEADER[0] = element.first_name + ' ' + element.last_name


        let no_view = "<h2></h2>"

        if (element.non_lu_admin > 0) {
            no_view += ` <h2 id="count_nbr_` + element.id + `"
            style="padding-top: 2px; border-radius: 7px; text-align: center; height: 20px; width: 20px;background-color: red;">
            `+ element.non_lu_admin + ` </h2>`
        }
        else {
            no_view += '<h2 id="count_nbr_' + element.id + '"></h2>'
        }





        let row = `

        <li class="listes" id="select_`+ element.id + `" onclick= all_discussion(` + element.id + `,"` + element.user_name + `") style=" margin-left:-10px;   display: flex; flex-direction: row;align-items: center;justify-content: space-between;">
 
 
        <img style="width: 40px;height: 40px;" src="`+ element.img_user + `"">
        <div style="padding-right:25px;">
            <h2> `+ element.first_name + ' ' + element.last_name + `</h2>

            <div
                style=" width: 170px; margin-top: 10px;   display: flex; flex-direction: row;align-items: center;justify-content: space-between;">
                <h2 style="font-size: 12px !important;" > ` + Cut_word(element.last_message) + `</h2>

                `+ no_view + `
            </div>

        </div>

        </li>
`

        document.getElementById('les_discussions').innerHTML += row


    });


    if (ID_SELECT.length > 0) {
        document.getElementById('select_' + ID_SELECT[0]).style.backgroundColor = "#5e616a";

    }


}


















function all_discussion(id, user_name) {

    document.getElementById('content_header').innerHTML = `
            
                <div>
                    <h2>`+ TITLE_HEADER[0] + `</h2>
                    <h3>`+ user_name + `</h3>
                </div>
                `

    // #################################################
    // #################################################


    ID_SELECT[0] = id

    let btn_choix = document.querySelectorAll('.listes');

    for (let j = 0; j < btn_choix.length; j++) {
        btn_choix[j].style.backgroundColor = "";
    }

    document.getElementById('select_' + id).style.backgroundColor = "#5e616a";






    let les_donnees = new FormData();

    les_donnees.append("user_name", user_name);


    fetch(URL + '/Message_per_user_admin',
        {
            method: 'post',
            body: les_donnees,
            headers: {
                Accept: "application/json",
            }
        }
    ).then(response => response.json())
        .then(response => {

            if (response.resultat.length > 0) {

                // document.getElementById("liste_" + id).style.backgroundColor = 'red'

                document.getElementById("count_nbr_" + id).style.display = 'none'

                BASE_DISCUSSION = []  // vider mon tableau de discusson

                document.getElementById('chat').innerHTML = ''


                USER_NAMES[0] = user_name

                response.resultat.forEach(element => {
                    BASE_DISCUSSION.push(element)
                });



                Nos_discussion()
            } else {
                document.getElementById('chat').innerHTML = ''
                // setListe_discusion([])
            }

        })
        .catch((error) => {

            console.log(error);
        });





}




function Nos_discussion() {



    BASE_DISCUSSION.sort((a, b) => a.id - b.id).forEach(element => {


        let row = ''
        let img_bien = ''

        if (element.image_message.trim() != "") {
            img_bien = `<div><img style="width: 100%;height:100px;" src="` + element.image_message + `""></div>`
        }
        if (element.emetteur == USER_NAMES[0]) {
            row += `
            <li class="you" id="` + element.id + `">
                    <div class="entete">
                        <span class="status green"></span>
                        <h2>Lui</h2>
                        <h3>` + element.dates + `</h3>
                    </div>
                    <div class="triangle"></div>
                    <div class="message">
                    `+ img_bien + `
                    ` + element.message + `
                    </div>
                </li>
            `
        }
        else {
            row += `
            <li class="me" id="` + element.id + `">
                    <div class="entete">
                        <h3>` + element.dates + `</h3>
                        <h2>Moi</h2>
                        <span class="status blue"></span>
                    </div>
                    <div class="triangle"></div>
                    <div class="message">
                    ` + element.message + `
                    </div>
                </li>
            `
        }



        document.getElementById('chat').innerHTML += row
    });

    document.getElementById('chat').scrollTop = document.getElementById('chat').scrollHeight


}



// window.oncontextmenu = function (e) {
//     e.preventDefault()
//     alert('Right Click')
// }



// $(function () {
//     $('#chat').on('contextmenu', 'li', function (e) { //Get li under ul and invoke on contextmenu
//         e.preventDefault(); //Prevent defaults
//         // alert(this.id); //alert the id
//         $("<div class='custom-menu'>Custom menu</div>")
//             .appendTo("body")
//             .css({ top: e.pageY + "px", left: e.pageX + "px" });
//     });
// });








$(document).on('keypress', function (e) {
    if (e.which == 13) {
        // alert('You pressed enter!');
        send_msg()
    }
});



function send_msg() {


    let message = document.getElementById('message').value.trim()

    if (USER_NAMES.length == 0) {
        alert('Sélectionnez un compte pour aborder la discussion')
    }
    else {

        if (message == '') {
            alert('Saisissez un text')
        } else {

            let les_donnees = new FormData();


            les_donnees.append("user_name", USER_NAMES[0]);
            les_donnees.append("message", message);



            fetch(URL + '/Admin_add_message',
                {
                    method: 'post',
                    body: les_donnees,
                    headers: {
                        Accept: "application/json",
                    }
                }
            ).then(response => response.json())
                .then(response => {

                    if (response.resultat == 'save') {
                        document.getElementById('message').value = ''
                    } else {
                        alert('error , réessayer')
                    }

                })
                .catch((error) => {

                    console.log(error);
                });

        }
    }
}





function Les_messages() {



    if (USER_NAMES.length > 0) {


        let les_donnees = new FormData();

        les_donnees.append("user_name", USER_NAMES[0]);


        fetch(URL + '/Message_per_user_admin',
            {
                method: 'post',
                body: les_donnees,
                headers: {
                    Accept: "application/json",
                }
            }
        ).then(response => response.json())
            .then(response => {

                if (response.resultat.length > 0) {

                    // BASE_DISCUSSION = []  // vider mon tableau de discusson

                    let recherche = response.resultat.filter(o1 => !BASE_DISCUSSION.some(o2 => o1.id === o2.id));
                    if (recherche.length > 0) {

                        document.getElementById('chat').innerHTML = ""

                        recherche.forEach(element_reche => {
                            BASE_DISCUSSION.push(element_reche)
                        });

                        Nos_discussion()
                    }

                }

            })
            .catch((error) => {

                console.log(error);
            });

    }
    else {

    }
}
